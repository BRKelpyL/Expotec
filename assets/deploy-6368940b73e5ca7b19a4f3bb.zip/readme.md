I used three breakpoints:

Small: 640px;
Medium: 641px to 1007px;
Large: 1008px+;

So... I organized css using that values, from smaller to bigger.

Made By MrPandous